# name=Korg nanoKONTROL Studio Link Pads
# supportedDevices=nanoKONTROL Studio
#
# FL Studio 25.x MIDI Script
# Version 5.1
#
# Clean LED Engine:
# - Kein Heartbeat.
# - Kein Scene-Resend.
# - Keine konkurrierenden LED-Update-Routinen.
# - Eine zentrale Funktion rendert den kompletten LED-Zustand für alle 5 Scenes.
#
# Ziel:
# - Fader/Knobs bleiben über alle 5 Scenes identisch.
# - Buttons/Pads bleiben pro Scene unterschiedlich.
# - 32 Buttons pro Scene = 160 mögliche Zuordnungen.
# - Maus-Mute/Entmute wird erkannt.
# - LED:
#     frei = aus
#     gemutet = dauerhaft an
#     ungemutet = kurzer Beat-Pulse.
#
# Voraussetzungen:
# - Assignable Mode
# - LED Mode = External in allen Scenes
# - Mitgelieferte Korg-Konfiguration: Buttons in Scene 1-5 auf MIDI-Kanal 1-5

import re
import time

import midi
import device
import channels
import ui
import transport
import mixer

SCRIPT_NAME = "Korg nanoKONTROL Studio Link Pads"
DEBUG = False

# Fader/Knobs aus deiner Hardware-Analyse.
FADER_CCS = [2, 3, 4, 5, 6, 8, 9, 12]
KNOB_CCS  = [13, 14, 15, 16, 17, 18, 19, 20]
NORMALIZE_CCS = FADER_CCS + KNOB_CCS
TARGET_CHAN = 0

# Buttons aus deiner Hardware-Analyse.
CYCLE_CC = 54
PAD_CCS = (
    list(range(21, 29)) +   # Reihe 1: P1-P8
    list(range(29, 37)) +   # Reihe 2: P9-P16
    list(range(38, 46)) +   # Reihe 3: P17-P24
    list(range(46, 54))     # Reihe 4: P25-P32
)

LED_ON = 127
LED_OFF = 0

# Beat-Pulse:
PULSE_SECONDS = 0.10
MIN_BEAT_INTERVAL = 0.12
STEPS_PER_BEAT = 4

VISIBLE_MARKER_FMT = "‹NK:S{}:P{}›"
PAD_PATTERN = r"(?:[1-9]|[12][0-9]|3[0-2])"
MARKER_RE_ANY = re.compile(
    r"\s*(?:\[NK:S([1-5]):P(" + PAD_PATTERN + r")\]|‹NK:S([1-5]):P(" + PAD_PATTERN + r")›)"
)

current_scene = 1
link_armed = False

pulse_active = False
pulse_until = 0.0
last_beat_key = None
last_beat_time = 0.0

mappings = {}
last_mute_states = {}

last_mapping_scan = 0.0
MAPPING_SCAN_INTERVAL = 0.5

last_mute_poll = 0.0
MUTE_POLL_INTERVAL = 0.12

led_send_error_count = 0


def log(msg):
    if DEBUG:
        print("[{}] {}".format(SCRIPT_NAME, msg))


def hint(msg):
    try:
        ui.setHintMsg(msg)
    except Exception:
        pass
    print("[{}] {}".format(SCRIPT_NAME, msg))


def now():
    try:
        return time.monotonic()
    except Exception:
        return time.time()


def scene_from_event(event):
    # Buttons sind durch die Korg-Konfiguration pro Scene auf MIDI Ch 1-5 gesetzt.
    # B0=Scene1, B1=Scene2, ...
    try:
        st = int(event.status)
        if (st & 0xF0) == midi.MIDI_CONTROLCHANGE:
            scene = (st & 0x0F) + 1
            if 1 <= scene <= 5:
                return scene
    except Exception:
        pass

    try:
        scene = int(event.midiChan) + 1
        if 1 <= scene <= 5:
            return scene
    except Exception:
        pass

    return current_scene


def channel_count():
    for fn in (lambda: channels.channelCount(True), lambda: channels.channelCount(1), lambda: channels.channelCount()):
        try:
            return int(fn())
        except Exception:
            pass
    return 0


def is_valid_channel(ch):
    try:
        return 0 <= int(ch) < channel_count()
    except Exception:
        return False


def selected_channel():
    for fn in (lambda: channels.selectedChannel(True, 0, True), lambda: channels.selectedChannel(True), lambda: channels.selectedChannel()):
        try:
            return int(fn())
        except Exception:
            pass
    return -1


def channel_name(ch):
    for args in ((int(ch), True), (int(ch),)):
        try:
            return channels.getChannelName(*args)
        except Exception:
            pass
    return ""


def set_channel_name(ch, name):
    for fn in (lambda: channels.setChannelName(int(ch), str(name), True), lambda: channels.setChannelName(int(ch), str(name))):
        try:
            fn()
            return True
        except Exception:
            pass

    hint("FEHLER: Channelname konnte nicht geändert werden.")
    return False


def is_muted(ch):
    for args in ((int(ch), True), (int(ch),)):
        try:
            return bool(channels.isChannelMuted(*args))
        except Exception:
            pass
    return False


def toggle_mute(ch):
    for fn in (lambda: channels.muteChannel(int(ch), -1, True), lambda: channels.muteChannel(int(ch), -1), lambda: channels.muteChannel(int(ch))):
        try:
            fn()
            return True
        except Exception:
            pass

    hint("FEHLER: Mute konnte nicht geschaltet werden.")
    return False


def strip_markers(name):
    return MARKER_RE_ANY.sub("", name or "").strip()


def markers_in_name(name):
    out = []
    for m in MARKER_RE_ANY.finditer(name or ""):
        scene = m.group(1) or m.group(3)
        pad = m.group(2) or m.group(4)
        if scene and pad:
            out.append((int(scene), int(pad)))
    return out


def make_marker(scene, pad):
    return VISIBLE_MARKER_FMT.format(int(scene), int(pad))


def pad_from_cc(cc):
    try:
        return PAD_CCS.index(int(cc)) + 1
    except ValueError:
        return None


def clean_duplicate_markers():
    """
    Pro Channel bleibt nur der letzte NK-Marker erhalten.
    """
    for ch in range(channel_count()):
        name = channel_name(ch)
        found = markers_in_name(name)

        if not found:
            continue

        clean = strip_markers(name)
        scene, pad = found[-1]
        new_name = (clean + " " + make_marker(scene, pad)).strip()

        if new_name != name:
            set_channel_name(ch, new_name)


def rebuild_mappings(cleanup=False):
    global mappings, last_mapping_scan

    if cleanup:
        clean_duplicate_markers()

    mappings = {}
    for ch in range(channel_count()):
        name = channel_name(ch)
        found = markers_in_name(name)
        if found:
            scene, pad = found[-1]
            mappings[(scene, pad)] = ch

    last_mapping_scan = now()


def maybe_rebuild_mappings():
    if (now() - last_mapping_scan) >= MAPPING_SCAN_INTERVAL:
        rebuild_mappings(cleanup=False)


def remove_specific_marker(ch, scene, pad):
    name = channel_name(ch)
    pattern = re.compile(
        r"\s*(?:\[NK:S{}:P{}\]|‹NK:S{}:P{}›)".format(
            int(scene), int(pad), int(scene), int(pad)
        )
    )
    new = pattern.sub("", name or "").strip()
    if new != name:
        set_channel_name(ch, new)


def remove_all_markers(ch):
    name = channel_name(ch)
    new = strip_markers(name)
    if new != name:
        set_channel_name(ch, new)


def remove_pad_everywhere(scene, pad):
    for ch in range(channel_count()):
        remove_specific_marker(ch, scene, pad)


def assign_toggle(scene, pad):
    rebuild_mappings(cleanup=True)

    ch = selected_channel()
    if not is_valid_channel(ch):
        hint("Kein gültiger Channel ausgewählt.")
        return

    key = (int(scene), int(pad))
    old_ch = mappings.get(key)

    name = channel_name(ch)
    clean = strip_markers(name)

    if old_ch == ch:
        remove_specific_marker(ch, scene, pad)
        hint("Gelöst: S{} P{} von Channel {}".format(scene, pad, ch + 1))
        rebuild_mappings(cleanup=True)
        render_leds_all_scenes()
        return

    if old_ch is not None and is_valid_channel(old_ch):
        remove_specific_marker(old_ch, scene, pad)

    # Pro Channel nur ein Marker:
    remove_all_markers(ch)

    # Scene/Pad eindeutig halten:
    remove_pad_everywhere(scene, pad)

    new_name = (clean + " " + make_marker(scene, pad)).strip()

    if set_channel_name(ch, new_name):
        hint("Verlinkt: S{} P{} -> Channel {} ({})".format(scene, pad, ch + 1, clean))
    else:
        hint("Verlinkung fehlgeschlagen.")

    rebuild_mappings(cleanup=True)
    sync_mute_cache()
    render_leds_all_scenes()


def send_led(scene, pad, value):
    global led_send_error_count

    cc = PAD_CCS[int(pad) - 1]
    chan = int(scene) - 1

    try:
        device.midiOutMsg(midi.MIDI_CONTROLCHANGE, chan, cc, int(value))
    except Exception as exc:
        led_send_error_count += 1
        if led_send_error_count <= 3:
            hint("LED-Sendefehler: Output-Port prüfen. {}".format(exc))


def led_value(scene, pad):
    ch = mappings.get((int(scene), int(pad)))

    if ch is None or not is_valid_channel(ch):
        return LED_OFF

    if is_muted(ch):
        return LED_ON

    return LED_ON if pulse_active else LED_OFF


def render_leds_all_scenes():
    """
    Zentrale LED-Engine.
    Diese Funktion ist die einzige Stelle, die den kompletten LED-Zustand berechnet.
    Sie sendet absichtlich alle 5 Scenes, weil der Controller Scene-Wechsel nicht meldet.
    """
    maybe_rebuild_mappings()

    for scene in range(1, 6):
        for pad in range(1, 33):
            send_led(scene, pad, led_value(scene, pad))


def handle_pad(scene, pad):
    rebuild_mappings(cleanup=False)

    ch = mappings.get((int(scene), int(pad)))

    if ch is None or not is_valid_channel(ch):
        hint("S{} P{} frei. CYCLE drücken, dann Pad/Button drücken.".format(scene, pad))
        render_leds_all_scenes()
        return

    if toggle_mute(ch):
        last_mute_states[ch] = is_muted(ch)
        hint("S{} P{} -> Channel {} Mute {}".format(
            scene, pad, ch + 1, "AN" if is_muted(ch) else "AUS"
        ))
        render_leds_all_scenes()


def normalize_fader_knob(event):
    # Seit v5.1 bereits in OnMidiIn erledigt.
    return int(event.data1) in NORMALIZE_CCS


def get_beat_key():
    try:
        step_pos = int(mixer.getSongStepPos())
        return step_pos // STEPS_PER_BEAT
    except Exception:
        return None


def update_pulse():
    """
    Beat-Pulse über mixer.getSongStepPos().
    Bei jedem neuen Beat: pulse_active kurz an.
    Danach nach PULSE_SECONDS wieder aus.
    """
    global pulse_active, pulse_until, last_beat_key, last_beat_time

    t = now()

    try:
        playing = bool(transport.isPlaying())
    except Exception:
        playing = False

    if not playing:
        if pulse_active:
            pulse_active = False
            pulse_until = 0.0
            last_beat_key = None
            render_leds_all_scenes()
        return

    beat_key = get_beat_key()
    if beat_key is None:
        return

    if last_beat_key is None:
        last_beat_key = beat_key
        last_beat_time = t
        pulse_active = True
        pulse_until = t + PULSE_SECONDS
        render_leds_all_scenes()
        return

    if beat_key != last_beat_key:
        if beat_key < last_beat_key or (t - last_beat_time) >= MIN_BEAT_INTERVAL:
            last_beat_key = beat_key
            last_beat_time = t
            pulse_active = True
            pulse_until = t + PULSE_SECONDS
            render_leds_all_scenes()

    if pulse_active and t >= pulse_until:
        pulse_active = False
        render_leds_all_scenes()


def sync_mute_cache():
    global last_mute_states

    last_mute_states = {}
    for ch in mappings.values():
        if ch is not None and is_valid_channel(ch):
            last_mute_states[ch] = is_muted(ch)


def poll_mute_changes():
    """
    Erkennt Maus-Mute/Unmute.
    Pollt nur verknüpfte Channels.
    """
    global last_mute_poll

    t = now()
    if (t - last_mute_poll) < MUTE_POLL_INTERVAL:
        return

    last_mute_poll = t
    maybe_rebuild_mappings()

    changed = False
    seen = set()

    for ch in mappings.values():
        if ch is None or not is_valid_channel(ch):
            continue

        seen.add(ch)
        muted = is_muted(ch)

        if ch not in last_mute_states:
            last_mute_states[ch] = muted
            continue

        if last_mute_states[ch] != muted:
            last_mute_states[ch] = muted
            changed = True

    for ch in list(last_mute_states.keys()):
        if ch not in seen:
            del last_mute_states[ch]
            changed = True

    if changed:
        render_leds_all_scenes()


def initialize_project_state():
    rebuild_mappings(cleanup=True)
    sync_mute_cache()
    render_leds_all_scenes()


def OnInit():
    hint("Korg Link Pads v5.1 geladen. Raw-Input-Link-Fix aktiv.")
    initialize_project_state()


def OnProjectLoad(status):
    initialize_project_state()


def OnDeInit():
    for scene in range(1, 6):
        for pad in range(1, 33):
            send_led(scene, pad, LED_OFF)


def OnControlChange(event):
    global current_scene, link_armed

    cc = int(event.data1)
    val = int(event.data2)
    scene = scene_from_event(event)

    # CYCLE: Link-Modus aktivieren.
    if cc == CYCLE_CC:
        if val > 0:
            link_armed = True
            current_scene = scene
            hint("Link-Modus AN. Jetzt Pad/Button drücken.")
        event.handled = True
        return

    # Buttons/Pads: scene-abhängig.
    pad = pad_from_cc(cc)
    if pad is not None:
        if 1 <= scene <= 5:
            current_scene = scene

        if val > 0:
            if link_armed:
                link_armed = False
                assign_toggle(scene, pad)
            else:
                handle_pad(scene, pad)

        event.handled = True
        return

    # Fader/Knobs wurden bereits in OnMidiIn auf Kanal 1 normalisiert.
    event.handled = False


def OnMidiIn(event):
    # Frühestmögliche Normalisierung für Remote Links.
    # Nur Fader und Knobs werden auf MIDI-Kanal 1 gesetzt.
    # Buttons/Pads behalten ihre Scene-Kanäle 1-5.
    try:
        status = int(event.status)
        data1 = int(event.data1)
        if (status & 0xF0) == midi.MIDI_CONTROLCHANGE and data1 in NORMALIZE_CCS:
            event.status = midi.MIDI_CONTROLCHANGE | TARGET_CHAN
    except Exception:
        pass
    event.handled = False


def OnIdle():
    poll_mute_changes()
    update_pulse()


def OnRefresh(flags):
    poll_mute_changes()
    update_pulse()


def OnDirtyChannel(index, flag):
    poll_mute_changes()
    render_leds_all_scenes()


def OnUpdateBeatIndicator(value):
    # Nicht verwenden. Beat läuft über mixer.getSongStepPos().
    pass
