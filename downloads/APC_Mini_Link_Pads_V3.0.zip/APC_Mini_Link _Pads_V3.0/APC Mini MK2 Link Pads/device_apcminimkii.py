#name=APC Mini MK2 Link Pads

import time
import device
import transport
import channels
import utils
import ui

SHIFT_NOTE = 122
PANIC_NOTE = 100
ARROW_UP_NOTE = 104
ARROW_DOWN_NOTE = 105

OFF = 0
WHITE = 3

PAD_MIN = 0
PAD_MAX = 63

SCENE_MIN = 112
SCENE_MAX = 119

SCENE_GREEN = 21
SHIFT_RED = 5
SHIFT_BRIGHT_RED = 72
PANIC_RED = 5

MOMENTARY_HOLD_TIME = 0.25
SCENE_BLINK_TIME = 0.35
PANIC_FLASH_TIME = 0.35
NAV_REPEAT_DELAY = 0.30
NAV_REPEAT_INTERVAL = 0.085
NAV_LED_RED = 72
CHANNEL_VIEW_HEIGHT = 4


APC_ASSIGNMENT_AUTO_REFRESH_INTERVAL = 0.75
APC_LAST_ASSIGNMENT_REFRESH = 0.0
APC_LAST_SELECTED_CHANNEL = -999


# Link Pads persistence without file I/O:
# Assignments are stored inside FL channel names as a small marker, e.g. [LP:S1:P36]
# This persists with the FLP project and avoids FL MIDI Python FileIO/subprocess errors.
LINK_TAG_PREFIX = "[LP:"
LEGACY_APC_TAG_PREFIX = "[APC:"
LINK_TAG_SUFFIX = "]"

assignments = {"scenes": {"1": {}}}
shift_held = False
current_scene = "1"

held_shift_pads = {}
momentary_active = {}
latch_on_release = set()

pad_hold_start = {}
pad_select_flash = {}

SELECT_HOLD_TIME = 0.4
SELECT_FLASH_TIME = 0.45
BEAT_BLINK_ON_RATIO = 0.60
BEAT_BLINK_CYCLE_BEATS = 1.0  # Link Pads: langsamerer, besser sichtbarer APC-Blink
BEAT_BLINK_MIN_BPM = 60
BEAT_BLINK_MAX_BPM = 240
APC_SELECTED_PAD_BLINK_ENABLED = True  # Link Pads: APC-Blink unabhängig von Melo/Runtime



def getCurrentBpmSafe():
    try:
        import mixer
        if hasattr(mixer, "getCurrentTempo"):
            try:
                bpm = mixer.getCurrentTempo(0)
            except:
                bpm = mixer.getCurrentTempo()
            bpm = float(bpm)
            while bpm > 300:
                bpm = bpm / 1000.0
            if bpm >= BEAT_BLINK_MIN_BPM and bpm <= BEAT_BLINK_MAX_BPM:
                return bpm
    except:
        pass

    try:
        if hasattr(transport, "getCurrentTempo"):
            bpm = float(transport.getCurrentTempo())
            while bpm > 300:
                bpm = bpm / 1000.0
            if bpm >= BEAT_BLINK_MIN_BPM and bpm <= BEAT_BLINK_MAX_BPM:
                return bpm
    except:
        pass

    return 150.0


def beatBlinkState():
    try:
        bpm = getCurrentBpmSafe()
        beat_len = 60.0 / bpm
        cycle_len = beat_len * BEAT_BLINK_CYCLE_BEATS
        phase = time.monotonic() % cycle_len
        return phase < (cycle_len * BEAT_BLINK_ON_RATIO)
    except:
        return True


scene_blink_state = False
last_scene_blink_time = 0.0
panic_flash_until = 0.0

# Clean LED Engine v15
# Nur updateLights() rendert den vollständigen APC-Zustand.
# MIDI-Ausgaben werden gecacht, damit identische LED-Werte nicht permanent neu gesendet werden.
_led_output_cache = {}
_last_render_blink_state = None
_last_render_scene_blink_state = None
_last_render_scene = None
_last_render_channel_signature = None
_last_render_time = 0.0
LED_RENDER_INTERVAL = 0.025

arrow_up_held = False
arrow_down_held = False
arrow_up_next_repeat = 0.0
arrow_down_next_repeat = 0.0

apc_restore_init_pending = True
apc_restore_init_attempts = 0
apc_restore_next_attempt_time = 0.0
apc_restore_last_found_count = -1



# Standalone-Version ohne Nova Stage, PM, Heartbeat oder JSON-Kommunikation.

def countApcTagsInChannels():
    count = 0
    try:
        for ch in range(channels.channelCount()):
            count = count + len(findApcTags(safeChannelName(ch)))
    except:
        pass
    return count


def restoreAssignmentsFromChannelNamesNow(source):
    try:
        rebuildAssignmentsFromChannelNames()
        updateLights()
        try:
            print("APC Link Pads assignments restored from channel names:", source)
        except:
            pass
        return True
    except Exception as e:
        try:
            print("APC Link Pads restore from channel names failed:", source, e)
        except:
            pass
        return False


def deferredInitRestoreAssignments():
    global apc_restore_init_pending, apc_restore_init_attempts
    global apc_restore_next_attempt_time, apc_restore_last_found_count

    if not apc_restore_init_pending:
        return

    now = time.monotonic()
    if now < apc_restore_next_attempt_time:
        return

    apc_restore_next_attempt_time = now + 0.50
    apc_restore_init_attempts = apc_restore_init_attempts + 1

    try:
        if channels.channelCount() <= 0:
            return
    except:
        return

    try:
        found = countApcTagsInChannels()
    except:
        found = 0

    # Keep trying for a longer time after full FL startup.
    # If markers appear later, restore again.
    if found > 0 and found != apc_restore_last_found_count:
        apc_restore_last_found_count = found
        restoreAssignmentsFromChannelNamesNow("OnIdle startup restore attempt " + str(apc_restore_init_attempts))

        # Keep checking briefly in case FL keeps loading more channels.
        if apc_restore_init_attempts >= 20:
            apc_restore_init_pending = False
        return

    if apc_restore_init_attempts in (1, 4, 10, 20, 40, 80):
        restoreAssignmentsFromChannelNamesNow("OnIdle fallback restore attempt " + str(apc_restore_init_attempts))

    # 80 attempts * 0.5 sec = up to ~40 seconds after FL startup.
    if apc_restore_init_attempts >= 80:
        apc_restore_init_pending = False




def forceAssignmentRefresh(reason=""):
    # Rebuild Link Pads assignment cache from current FL Studio channel markers.
    # This fixes stale cache after MIDI-script update / project load / old assignments.
    global APC_LAST_ASSIGNMENT_REFRESH
    try:
        restoreAssignmentsFromChannelNames()
    except Exception as e:
        try:
            print("APC Link Pads forceAssignmentRefresh restore failed:", reason, e)
        except:
            pass

    try:
        cleanupSelectFlash()
    except:
        pass

    try:
        updateLights()
    except Exception as e:
        try:
            print("APC Link Pads forceAssignmentRefresh updateLights failed:", reason, e)
        except:
            pass

    APC_LAST_ASSIGNMENT_REFRESH = time.monotonic()


def autoRefreshAssignments():
    global APC_LAST_ASSIGNMENT_REFRESH, APC_LAST_SELECTED_CHANNEL

    try:
        now = time.monotonic()
        selected = getSelectedChannel()

        if now - APC_LAST_ASSIGNMENT_REFRESH >= APC_ASSIGNMENT_AUTO_REFRESH_INTERVAL:
            APC_LAST_SELECTED_CHANNEL = selected
            return

        if selected != APC_LAST_SELECTED_CHANNEL:
            APC_LAST_SELECTED_CHANNEL = selected
            return
    except Exception as e:
        try:
            print("APC Link Pads autoRefreshAssignments failed:", e)
        except:
            pass



def OnInit():
    global apc_restore_init_pending, apc_restore_init_attempts
    global _led_output_cache, _last_render_blink_state
    global _last_render_scene_blink_state, _last_render_scene
    global _last_render_channel_signature, _last_render_time

    apc_restore_init_pending = False
    apc_restore_init_attempts = 0

    _led_output_cache = {}
    _last_render_blink_state = None
    _last_render_scene_blink_state = None
    _last_render_scene = None
    _last_render_channel_signature = None
    _last_render_time = 0.0

    # Marker im Channelnamen sind die einzige persistente Zuweisungsquelle.
    rebuildAssignmentsFromChannelNames()
    clearLights()
    updateLights(True)

    try:
        print("APC Mini MK2 Link Pads v3.0 geladen")
    except:
        pass


def OnDeInit():
    clearLights()


def OnRefresh(flags):
    # FL-Projekt/Channel-Rack geändert: Marker neu einlesen und einmal vollständig rendern.
    rebuildAssignmentsFromChannelNames()
    updateLights(True)


def OnIdle():
    global scene_blink_state, last_scene_blink_time

    checkMomentaryHolds()
    cleanupSelectFlash()
    handleArrowRepeat()

    now = time.monotonic()
    if now - last_scene_blink_time >= SCENE_BLINK_TIME:
        last_scene_blink_time = now
        scene_blink_state = not scene_blink_state

    # Ein einziger Renderer entscheidet über sämtliche Pad-/Scene-/Utility-LEDs.
    updateLights(False)


def OnNoteOn(event):
    global shift_held, current_scene, arrow_up_held, arrow_down_held, arrow_up_next_repeat, arrow_down_next_repeat

    event.handled = True
    note = event.data1

    if event.data2 == 0:
        return

    if note == SHIFT_NOTE:
        shift_held = True
        updateUtilityButtons()
        return

    if note == PANIC_NOTE:
        globalMutePanic()
        return

    if note == ARROW_UP_NOTE:
        arrow_up_held = True
        arrow_up_next_repeat = time.monotonic() + NAV_REPEAT_DELAY
        navigateChannel(-1)
        updateUtilityButtons()
        return

    if note == ARROW_DOWN_NOTE:
        arrow_down_held = True
        arrow_down_next_repeat = time.monotonic() + NAV_REPEAT_DELAY
        navigateChannel(1)
        updateUtilityButtons()
        return

    if SCENE_MIN <= note <= SCENE_MAX:
        current_scene = str((note - SCENE_MIN) + 1)
        ensureScene(current_scene)
        updateLights()
        return

    if note < PAD_MIN or note > PAD_MAX:
        return

    if shift_held:
        startShiftPadHold(note)
    else:
        pad_hold_start[note] = time.monotonic()


def OnNoteOff(event):
    global shift_held, arrow_up_held, arrow_down_held

    event.handled = True
    note = event.data1

    if note == SHIFT_NOTE:
        shift_held = False
        markMomentaryForLatch()
        updateUtilityButtons()
        return

    if note == ARROW_UP_NOTE:
        arrow_up_held = False
        updateUtilityButtons()
        return

    if note == ARROW_DOWN_NOTE:
        arrow_down_held = False
        updateUtilityButtons()
        return

    if PAD_MIN <= note <= PAD_MAX:

        if shift_held or note in held_shift_pads:
            finishShiftPadHold(note)
            return

        if note in pad_hold_start:
            hold_time = time.monotonic() - pad_hold_start[note]
            del pad_hold_start[note]

            if hold_time < SELECT_HOLD_TIME:
                toggleAssignedChannel(note)
            else:
                selectAssignedChannel(note)

            updateLights()


def OnUpdateBeatIndicator(value):
    # Keine eigene Blink-/LED-Routine mehr.
    # Der zentrale Renderer verwendet eine absolute BPM-Phase über time.monotonic().
    updateLights(False)


def startShiftPadHold(pad):
    scene = getCurrentScene()
    key = str(pad)

    if key not in scene:
        assignSelectedChannelToPad(pad)
        updateLights()
        return

    held_shift_pads[pad] = time.monotonic()


def finishShiftPadHold(pad):
    if pad not in held_shift_pads:
        return

    held_time = time.monotonic() - held_shift_pads[pad]
    del held_shift_pads[pad]

    if pad in momentary_active:
        if pad in latch_on_release:
            finishLatchedMomentary(pad)
        else:
            stopMomentary(pad)
        return

    if held_time < MOMENTARY_HOLD_TIME:
        deletePadAssignment(pad)
        updateLights()


def checkMomentaryHolds():
    if not shift_held:
        return

    now = time.monotonic()

    for pad, start_time in list(held_shift_pads.items()):
        if pad in momentary_active:
            continue

        if now - start_time >= MOMENTARY_HOLD_TIME:
            startMomentary(pad)


def startMomentary(pad):
    scene = getCurrentScene()
    key = str(pad)

    if key not in scene:
        return

    ch = resolveChannel(scene[key])

    if not isValidChannel(ch):
        return

    momentary_active[pad] = ch

    try:
        if channels.isChannelMuted(ch):
            channels.muteChannel(ch)
    except:
        pass

    sendLightMsg(pad, WHITE, 0x96)


def stopMomentary(pad):
    ch = momentary_active.get(pad, -1)

    if isValidChannel(ch):
        try:
            if not channels.isChannelMuted(ch):
                channels.muteChannel(ch)
        except:
            pass

    if pad in momentary_active:
        del momentary_active[pad]

    if pad in latch_on_release:
        latch_on_release.remove(pad)

    updateLights()


def markMomentaryForLatch():
    for pad in list(momentary_active.keys()):
        latch_on_release.add(pad)


def finishLatchedMomentary(pad):
    ch = momentary_active.get(pad, -1)

    if isValidChannel(ch):
        try:
            if channels.isChannelMuted(ch):
                channels.muteChannel(ch)
        except:
            pass

    if pad in momentary_active:
        del momentary_active[pad]

    if pad in latch_on_release:
        latch_on_release.remove(pad)

    updateLights()


def deletePadAssignment(pad):
    scene = getCurrentScene()
    key = str(pad)

    if key in scene:
        ch = resolveChannel(scene[key])
        removePadAssignmentTagFromChannel(ch, current_scene, pad)
        del scene[key]
        saveAssignments()
        sendLightMsg(pad, OFF, 0x90)


def globalMutePanic():
    global panic_flash_until

    for scene in assignments.get("scenes", {}).values():
        for data in scene.values():
            ch = resolveChannel(data)

            if isValidChannel(ch):
                try:
                    if not channels.isChannelMuted(ch):
                        channels.muteChannel(ch)
                except:
                    pass

    panic_flash_until = time.monotonic() + PANIC_FLASH_TIME
    updateLights()


def assignSelectedChannelToPad(pad):
    ch = getSelectedChannel()

    if ch < 0:
        print("Kein Channel ausgewählt")
        return

    scene = getCurrentScene()
    persistPadAssignmentInChannelName(ch, current_scene, pad)
    scene[str(pad)] = makeChannelSignature(ch)
    saveAssignments()

    try:
        if not channels.isChannelMuted(ch):
            channels.muteChannel(ch)
    except:
        pass


def toggleAssignedChannel(pad):
    scene = getCurrentScene()
    key = str(pad)

    if key not in scene:
        return

    ch = resolveChannel(scene[key])

    if not isValidChannel(ch):
        sendLightMsg(pad, OFF, 0x90)
        return

    try:
        was_muted = bool(channels.isChannelMuted(ch))
    except:
        was_muted = False

    target_muted = not was_muted
    changed = False

    # FL-Studio-Versionen unterscheiden sich bei der Channel-Mute-API.
    # Deshalb mehrere kompatible Varianten probieren und den Zustand danach prüfen.
    try:
        channels.muteChannel(ch)
        changed = True
    except:
        pass

    if not changed:
        try:
            channels.muteChannel(ch, target_muted)
            changed = True
        except:
            pass

    if not changed and hasattr(channels, "setChannelMuted"):
        try:
            channels.setChannelMuted(ch, target_muted)
            changed = True
        except:
            pass

    if not changed and hasattr(channels, "setChannelMute"):
        try:
            channels.setChannelMute(ch, target_muted)
            changed = True
        except:
            pass

    # Falls muteChannel(ch) zwar keinen Fehler wirft, aber nicht umschaltet,
    # einmal die explizite Variante versuchen.
    try:
        now_muted = bool(channels.isChannelMuted(ch))
        if now_muted == was_muted:
            try:
                channels.muteChannel(ch, target_muted)
            except:
                pass
    except:
        pass

    updateLights(True)




def navigateChannel(direction):
    ch = getSelectedChannel()

    if ch < 0:
        ch = 0

    ch = ch + direction
    ch = max(0, min(ch, channels.channelCount() - 1))

    try:
        channels.selectOneChannel(ch)
    except:
        try:
            channels.selectChannel(ch)
        except:
            pass

    followChannelRack(ch)

    flashAssignedPadForChannel(ch)


def handleArrowRepeat():
    global arrow_up_next_repeat, arrow_down_next_repeat

    now = time.monotonic()

    if arrow_up_held and now >= arrow_up_next_repeat:
        navigateChannel(-1)
        arrow_up_next_repeat = now + NAV_REPEAT_INTERVAL

    if arrow_down_held and now >= arrow_down_next_repeat:
        navigateChannel(1)
        arrow_down_next_repeat = now + NAV_REPEAT_INTERVAL


def followChannelRack(ch):
    # Important:
    # Do not call ui.crDisplayRect() here.
    # crDisplayRect changes the Fire red Channel Rack rectangle / display zone.
    # The APC arrow navigation should only select channels and must not touch the Fire grid.
    return

def flashAssignedPadForChannel(ch):
    scene = getCurrentScene()

    for pad, data in scene.items():
        pad_num = int(pad)

        if resolveChannel(data) == ch:
            pad_select_flash[pad_num] = time.monotonic() + max(SELECT_FLASH_TIME, (60.0 / getCurrentBpmSafe()) * 2.0)
            sendLightMsg(pad_num, WHITE, 0x96)


def selectAssignedChannel(pad):
    scene = getCurrentScene()
    key = str(pad)

    if key not in scene:
        return

    ch = resolveChannel(scene[key])

    if not isValidChannel(ch):
        return

    try:
        channels.selectOneChannel(ch)
    except:
        try:
            channels.selectChannel(ch)
        except:
            pass

    followChannelRack(ch)
    pad_select_flash[pad] = time.monotonic() + max(SELECT_FLASH_TIME, (60.0 / getCurrentBpmSafe()) * 2.0)



def isChannelSelectedSafe(ch):
    try:
        return bool(channels.isChannelSelected(ch))
    except:
        try:
            return int(channels.selectedChannel()) == int(ch)
        except:
            return False


def selectedApcBlinkColor(ch, fallback_color):
    # Nur der aktuell ausgewählte, per Link-Pads-Marker verknüpfte Channel blinkt.
    # Die Phase ist absolut BPM-abhängig und kann nicht durch Timer-Dopplung beschleunigen.
    if APC_SELECTED_PAD_BLINK_ENABLED and isChannelSelectedSafe(ch):
        return WHITE if beatBlinkState() else OFF

    return fallback_color


def cleanupSelectFlash():
    now = time.monotonic()

    for pad, end_time in list(pad_select_flash.items()):
        if now >= end_time:
            del pad_select_flash[pad]


def makeLedRenderSignature():
    try:
        selected = getSelectedChannel()
    except:
        selected = -1

    muted = []
    scene = getCurrentScene()
    for pad in range(64):
        data = scene.get(str(pad))
        ch = resolveChannel(data) if data is not None else -1
        if isValidChannel(ch):
            try:
                muted.append((pad, ch, bool(channels.isChannelMuted(ch))))
            except:
                muted.append((pad, ch, False))

    return (current_scene, selected, tuple(muted), tuple(sorted(momentary_active.keys())), tuple(sorted(pad_select_flash.keys())))


def updateLights(force=False):
    global _last_render_blink_state, _last_render_scene_blink_state
    global _last_render_scene, _last_render_channel_signature, _last_render_time

    now = time.monotonic()
    blink_state = beatBlinkState()
    signature = makeLedRenderSignature()

    changed = (
        force
        or blink_state != _last_render_blink_state
        or scene_blink_state != _last_render_scene_blink_state
        or current_scene != _last_render_scene
        or signature != _last_render_channel_signature
    )

    if not changed and (now - _last_render_time) < LED_RENDER_INTERVAL:
        return

    _last_render_time = now
    _last_render_blink_state = blink_state
    _last_render_scene_blink_state = scene_blink_state
    _last_render_scene = current_scene
    _last_render_channel_signature = signature

    scene = getCurrentScene()

    for pad in range(64):
        key = str(pad)

        if pad in pad_select_flash:
            sendLightMsg(pad, WHITE if blink_state else OFF, 0x96)
            continue

        if key not in scene:
            sendLightMsg(pad, OFF, 0x90)
            continue

        if pad in momentary_active:
            sendLightMsg(pad, WHITE, 0x96)
            continue

        ch = resolveChannel(scene[key])
        if not isValidChannel(ch):
            sendLightMsg(pad, OFF, 0x90)
            continue

        base_color = getChannelApcColor(ch)

        try:
            channel_active = not bool(channels.isChannelMuted(ch))
        except:
            channel_active = True

        # Aktive APC-Zuweisungen blinken unabhängig von FL-Transport,
        # Melo-Laufzeit, Fire und ausgewähltem Channel.
        # Gemutete Channels bleiben zur Orientierung dauerhaft in ihrer Farbe sichtbar.
        if channel_active:
            color = base_color if blink_state else OFF
        else:
            color = base_color

        sendLightMsg(pad, color, 0x96)

    updateSceneButtons()
    updateUtilityButtons()


def updateSceneButtons():
    for note in range(SCENE_MIN, SCENE_MAX + 1):
        scene_num = str((note - SCENE_MIN) + 1)

        if scene_num == current_scene:
            device.midiOutMsg(0x90 + (note << 8) + (SCENE_GREEN << 16))
            continue

        if sceneHasActiveChannel(scene_num):
            if scene_blink_state:
                device.midiOutMsg(0x90 + (note << 8) + (SCENE_GREEN << 16))
            else:
                device.midiOutMsg(0x90 + (note << 8) + (OFF << 16))
        else:
            device.midiOutMsg(0x90 + (note << 8) + (OFF << 16))


def updateUtilityButtons():
    if shift_held:
        device.midiOutMsg(0x90 + (SHIFT_NOTE << 8) + (SHIFT_BRIGHT_RED << 16))
    else:
        device.midiOutMsg(0x90 + (SHIFT_NOTE << 8) + (SHIFT_RED << 16))

    # Panic LED dauerhaft rot
    device.midiOutMsg(0x90 + (PANIC_NOTE << 8) + (PANIC_RED << 16))

    if arrow_up_held:
        device.midiOutMsg(0x90 + (ARROW_UP_NOTE << 8) + (NAV_LED_RED << 16))
    else:
        device.midiOutMsg(0x90 + (ARROW_UP_NOTE << 8) + (OFF << 16))

    if arrow_down_held:
        device.midiOutMsg(0x90 + (ARROW_DOWN_NOTE << 8) + (NAV_LED_RED << 16))
    else:
        device.midiOutMsg(0x90 + (ARROW_DOWN_NOTE << 8) + (OFF << 16))


def sceneHasActiveChannel(scene_num):
    ensureScene(scene_num)
    scene = assignments["scenes"][scene_num]

    for data in scene.values():
        ch = resolveChannel(data)
        if isValidChannel(ch) and not channels.isChannelMuted(ch):
            return True

    return False


def getCurrentScene():
    ensureScene(current_scene)
    return assignments["scenes"][current_scene]


def ensureScene(scene_num):
    global assignments

    if not isinstance(assignments, dict):
        assignments = {"scenes": {"1": {}}}

    if "scenes" not in assignments:
        old = assignments
        assignments = {"scenes": {"1": old}}

    if scene_num not in assignments["scenes"]:
        assignments["scenes"][scene_num] = {}


def namesMatchIgnoringApcTags(a, b):
    try:
        return stripApcTags(a) == stripApcTags(b)
    except:
        return a == b


def makeChannelSignature(ch):
    return {
        "name": safeChannelName(ch),
        "color": safeChannelColor(ch),
        "fx": safeTargetFx(ch),
        "last_index": ch
    }


def resolveChannel(data):
    try:
        if isinstance(data, int):
            if isValidChannel(data):
                return data
            return -1

        name = data.get("name", "")
        color = data.get("color", None)
        fx = data.get("fx", None)
        last_index = data.get("last_index", -1)

        # 1) First trust the remembered position, but only if the signature still matches.
        # This prevents big projects with duplicate channel names from jumping to the first matching name.
        if isValidChannel(last_index):
            if namesMatchIgnoringApcTags(safeChannelName(last_index), name) and safeChannelColor(last_index) == color and safeTargetFx(last_index) == fx:
                return last_index

        # 2) Strict match: name + color + FX track.
        for i in range(channels.channelCount()):
            if namesMatchIgnoringApcTags(safeChannelName(i), name) and safeChannelColor(i) == color and safeTargetFx(i) == fx:
                data["last_index"] = i
                return i

        # 3) Medium match: name + color only.
        # Useful if the mixer routing changed, but still avoids random "same name only" matches.
        matches = []
        for i in range(channels.channelCount()):
            if namesMatchIgnoringApcTags(safeChannelName(i), name) and safeChannelColor(i) == color:
                matches.append(i)

        if len(matches) == 1:
            data["last_index"] = matches[0]
            return matches[0]

        # 4) Last safety: if remembered index still has the same name, keep it.
        # This is safer than searching the whole rack by name and picking the first duplicate.
        if isValidChannel(last_index) and namesMatchIgnoringApcTags(safeChannelName(last_index), name):
            return last_index

        return -1
    except:
        return -1
def clearLights():
    global _led_output_cache
    _led_output_cache = {}
    for i in range(64):
        sendLightMsg(i, OFF, 0x90)

    for i in range(0x64, 0x80):
        device.midiOutMsg(0x90 + (i << 8) + (OFF << 16))


def sendLightMsg(note, color, status):
    global _led_output_cache
    key = (int(status), int(note))
    value = int(color)
    if _led_output_cache.get(key) == value:
        return
    _led_output_cache[key] = value
    try:
        device.midiOutMsg(int(status) + (int(note) << 8) + (value << 16))
    except:
        pass


def getSelectedChannel():
    try:
        return channels.selectedChannel()
    except:
        pass

    try:
        return channels.selectedChannel(1)
    except:
        pass

    try:
        return channels.channelNumber()
    except:
        return -1


def isValidChannel(ch):
    try:
        return ch >= 0 and ch < channels.channelCount()
    except:
        return False


def safeChannelName(ch):
    try:
        return channels.getChannelName(ch)
    except:
        return ""


def safeChannelColor(ch):
    try:
        return channels.getChannelColor(ch)
    except:
        return 0


def safeTargetFx(ch):
    try:
        return channels.getTargetFxTrack(ch)
    except:
        return -999


def getChannelApcColor(ch):
    try:
        r, g, b = utils.ColorToRGB(channels.getChannelColor(ch))
        r, g, b = saturateColor(r, g, b)
        return closestApcColor((r, g, b))[0]
    except:
        return 20


def saturateColor(r, g, b):
    max_c = max(r, g, b)
    min_c = min(r, g, b)

    if max_c == min_c:
        return min(255, max_c + 40), min(255, max_c + 40), min(255, max_c + 40)

    r = int((r - min_c) * 1.9)
    g = int((g - min_c) * 1.9)
    b = int((b - min_c) * 1.9)

    max_new = max(r, g, b)

    if max_new > 0:
        factor = 255 / max_new
        r = int(r * factor)
        g = int(g * factor)
        b = int(b * factor)

    return min(255, r), min(255, g), min(255, b)



# Zuweisungen werden direkt über Channel-Marker im FLP gespeichert.

# Link Pads channel-name persistence
def makeApcTag(scene_num, pad):
    return LINK_TAG_PREFIX + "S" + str(scene_num) + ":P" + str(pad) + LINK_TAG_SUFFIX


def findApcTags(name):
    tags = []
    try:
        for prefix in (LINK_TAG_PREFIX, LEGACY_APC_TAG_PREFIX):
            start = 0
            while True:
                a = name.find(prefix, start)
                if a < 0:
                    break
                b = name.find(LINK_TAG_SUFFIX, a)
                if b < 0:
                    break
                tags.append(name[a:b + len(LINK_TAG_SUFFIX)])
                start = b + len(LINK_TAG_SUFFIX)
    except:
        pass
    return tags


def stripApcTags(name):
    try:
        clean = str(name)
        for tag in findApcTags(clean):
            clean = clean.replace(tag, "")
        return " ".join(clean.split()).strip()
    except:
        return name


def parseApcTag(tag):
    try:
        # Format: [APC:S1:P36]
        body = tag.replace(LINK_TAG_PREFIX, "").replace(LEGACY_APC_TAG_PREFIX, "").replace(LINK_TAG_SUFFIX, "")
        parts = body.split(":")
        scene_num = parts[0].replace("S", "")
        pad = int(parts[1].replace("P", ""))
        return scene_num, pad
    except:
        return None, -1


def safeSetChannelName(ch, name):
    try:
        channels.setChannelName(ch, name)
        return True
    except:
        pass

    try:
        channels.selectOneChannel(ch)
        channels.setChannelName(name)
        return True
    except:
        pass

    try:
        channels.selectChannel(ch)
        channels.setChannelName(name)
        return True
    except:
        return False


def persistPadAssignmentInChannelName(ch, scene_num, pad):
    try:
        old = safeChannelName(ch)
        base = stripApcTags(old)
        tag = makeApcTag(scene_num, pad)
        new_name = (base + " " + tag).strip()
        ok = safeSetChannelName(ch, new_name)
        try:
            print("APC Link Pads assignment tag saved:", new_name, ok)
        except:
            pass
        return ok
    except Exception as e:
        try:
            print("APC Link Pads assignment tag save failed:", e)
        except:
            pass
        return False


def removePadAssignmentTagFromChannel(ch, scene_num, pad):
    try:
        if not isValidChannel(ch):
            return

        name = safeChannelName(ch)
        tag = makeApcTag(scene_num, pad)
        if tag in name:
            safeSetChannelName(ch, stripApcTags(name))
    except:
        pass


def rebuildAssignmentsFromChannelNames():
    global assignments

    rebuilt = {"scenes": {"1": {}}}

    try:
        for ch in range(channels.channelCount()):
            name = safeChannelName(ch)
            tags = findApcTags(name)

            for tag in tags:
                scene_num, pad = parseApcTag(tag)
                if scene_num is None or pad < 0:
                    continue

                if "scenes" not in rebuilt:
                    rebuilt["scenes"] = {}

                if scene_num not in rebuilt["scenes"]:
                    rebuilt["scenes"][scene_num] = {}

                rebuilt["scenes"][scene_num][str(pad)] = makeChannelSignature(ch)
    except Exception as e:
        try:
            print("APC Link Pads rebuild assignments failed:", e)
        except:
            pass

    assignments = normalizeAssignments(rebuilt)
    ensureScene(current_scene)

    try:
        print("APC Link Pads assignments rebuilt from channel names")
    except:
        pass


def loadAssignments():
    # No file I/O in FL MIDI Python.
    # Rebuild assignments from persistent channel-name tags saved in the FLP.
    rebuildAssignmentsFromChannelNames()


def normalizeAssignments(raw):
    if not isinstance(raw, dict):
        return {"scenes": {"1": {}}}

    if "scenes" in raw and isinstance(raw["scenes"], dict):
        return raw

    return {"scenes": {"1": raw}}


def saveAssignments():
    # No file I/O. Assignments persist via FL channel name tags.
    try:
        print("APC Link Pads assignments persist via channel names")
    except:
        pass


APC_COLORS = (
    (0, 0, 0, 0),
    (2, 127, 127, 127),
    (3, 255, 255, 255),
    (5, 255, 0, 0),
    (9, 255, 84, 0),
    (13, 255, 255, 0),
    (17, 84, 255, 0),
    (21, 0, 255, 0),
    (29, 0, 255, 85),
    (33, 0, 255, 153),
    (37, 0, 169, 255),
    (41, 0, 85, 255),
    (45, 0, 0, 255),
    (49, 84, 0, 255),
    (53, 255, 0, 255),
    (57, 255, 0, 84),
    (72, 255, 0, 0),
    (78, 0, 169, 255),
    (87, 0, 255, 0),
    (96, 255, 127, 0),
    (109, 255, 225, 38),
    (119, 224, 255, 255),
)


def closestApcColor(rgb):
    r, g, b = rgb
    return min(APC_COLORS, key=lambda c: abs(r - c[1]) + abs(g - c[2]) + abs(b - c[3]))

def OnProjectLoad(status):
    try:
        rebuildAssignmentsFromChannelNames()
        updateLights(True)
    except:
        pass
