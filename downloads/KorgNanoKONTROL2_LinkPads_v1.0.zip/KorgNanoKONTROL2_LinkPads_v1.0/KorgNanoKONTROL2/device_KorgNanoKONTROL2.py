# name=Korg nanoKONTROL2 Link Pads
# supportedDevices=nanoKONTROL2
#
# FL Studio 25.x MIDI Script
# Version 1.2
#
# nanoKONTROL2-Version ohne Scenes oder Banken.
#
# Funktionen:
# - 8 Fader und 8 Drehregler bleiben frei für FL "Link to controller".
# - 24 Tasten (Solo, Mute, Record) steuern Channel-Rack-Mutes.
# - CYCLE drücken -> gewünschte Taste drücken:
#     ausgewählten Channel verlinken oder Verlinkung lösen.
# - Zuordnung wird im Channelnamen gespeichert: ‹NK2:P1›
# - LED:
#     frei = aus
#     gemutet = dauerhaft an
#     ungemutet = kurzer Beat-Pulse
# - Maus-Mute/Entmute wird automatisch erkannt.
# - Transporttasten außer CYCLE spiegeln ihren eingehenden MIDI-Wert auf die LED.
#   Dadurch bestimmt der KORG Kontrol Editor pro Taste das Verhalten:
#     Momentary: 127 beim Drücken, 0 beim Loslassen
#     Toggle: abwechselnd 127 und 0
#   Die MIDI-Events werden weiterhin an FL Studio durchgelassen.
#
# Voraussetzungen am Controller:
# - Control Mode = CC
# - LED Mode = External
# - Standard-CC-Belegung oder folgende CCs:
#     Solo   = CC32-39
#     Mute   = CC48-55
#     Record = CC64-71
#     Cycle  = CC46

import re
import time

import midi
import device
import channels
import ui
import transport
import mixer

SCRIPT_NAME = "Korg nanoKONTROL2 Link Pads"
DEBUG = False

# Standardbelegung des nanoKONTROL2 im CC-Modus.
SOLO_CCS = list(range(32, 40))
MUTE_CCS = list(range(48, 56))
RECORD_CCS = list(range(64, 72))
PAD_CCS = SOLO_CCS + MUTE_CCS + RECORD_CCS

CYCLE_CC = 46

# Standard-CCs der übrigen Transport-/Navigationstasten.
# CYCLE bleibt exklusiv die Link-Taste und ist hier absichtlich nicht enthalten.
TRANSPORT_TOGGLE_CCS = [
    58,  # Track Left
    59,  # Track Right
    60,  # Marker Set
    61,  # Marker Left
    62,  # Marker Right
    43,  # Rewind
    44,  # Fast Forward
    42,  # Stop
    41,  # Play
    45,  # Record
]

LED_ON = 127
LED_OFF = 0

# Stabiler Beat-Pulse wie beim nanoKONTROL-Studio-Script.
PULSE_SECONDS = 0.10
MIN_BEAT_INTERVAL = 0.12
STEPS_PER_BEAT = 4

MARKER_FMT = "‹NK2:P{}›"
PAD_PATTERN = r"(?:[1-9]|1[0-9]|2[0-4])"
MARKER_RE = re.compile(
    r"\s*(?:\[NK2:P(" + PAD_PATTERN + r")\]|‹NK2:P(" + PAD_PATTERN + r")›)"
)

link_armed = False

pulse_active = False
pulse_until = 0.0
last_beat_key = None
last_beat_time = 0.0

mappings = {}
last_mute_states = {}

last_mapping_scan = 0.0
MAPPING_SCAN_INTERVAL = 0.5

last_mute_poll = 0.0
MUTE_POLL_INTERVAL = 0.12

led_send_error_count = 0


def log(msg):
    if DEBUG:
        print("[{}] {}".format(SCRIPT_NAME, msg))


def hint(msg):
    try:
        ui.setHintMsg(msg)
    except Exception:
        pass
    print("[{}] {}".format(SCRIPT_NAME, msg))


def now():
    try:
        return time.monotonic()
    except Exception:
        return time.time()


def channel_count():
    for fn in (
        lambda: channels.channelCount(True),
        lambda: channels.channelCount(1),
        lambda: channels.channelCount()
    ):
        try:
            return int(fn())
        except Exception:
            pass
    return 0


def is_valid_channel(ch):
    try:
        return 0 <= int(ch) < channel_count()
    except Exception:
        return False


def selected_channel():
    for fn in (
        lambda: channels.selectedChannel(True, 0, True),
        lambda: channels.selectedChannel(True),
        lambda: channels.selectedChannel()
    ):
        try:
            return int(fn())
        except Exception:
            pass
    return -1


def channel_name(ch):
    for args in ((int(ch), True), (int(ch),)):
        try:
            return channels.getChannelName(*args)
        except Exception:
            pass
    return ""


def set_channel_name(ch, name):
    for fn in (
        lambda: channels.setChannelName(int(ch), str(name), True),
        lambda: channels.setChannelName(int(ch), str(name))
    ):
        try:
            fn()
            return True
        except Exception:
            pass

    hint("FEHLER: Channelname konnte nicht geändert werden.")
    return False


def is_muted(ch):
    for args in ((int(ch), True), (int(ch),)):
        try:
            return bool(channels.isChannelMuted(*args))
        except Exception:
            pass
    return False


def toggle_mute(ch):
    for fn in (
        lambda: channels.muteChannel(int(ch), -1, True),
        lambda: channels.muteChannel(int(ch), -1),
        lambda: channels.muteChannel(int(ch))
    ):
        try:
            fn()
            return True
        except Exception:
            pass

    hint("FEHLER: Mute konnte nicht geschaltet werden.")
    return False


def strip_markers(name):
    return MARKER_RE.sub("", name or "").strip()


def markers_in_name(name):
    out = []
    for match in MARKER_RE.finditer(name or ""):
        pad = match.group(1) or match.group(2)
        if pad:
            out.append(int(pad))
    return out


def make_marker(pad):
    return MARKER_FMT.format(int(pad))


def pad_from_cc(cc):
    try:
        return PAD_CCS.index(int(cc)) + 1
    except ValueError:
        return None


def clean_duplicate_markers():
    """
    Pro Channel bleibt nur der letzte nanoKONTROL2-Marker erhalten.
    """
    for ch in range(channel_count()):
        name = channel_name(ch)
        found = markers_in_name(name)

        if not found:
            continue

        clean = strip_markers(name)
        pad = found[-1]
        new_name = (clean + " " + make_marker(pad)).strip()

        if new_name != name:
            set_channel_name(ch, new_name)


def rebuild_mappings(cleanup=False):
    global mappings, last_mapping_scan

    if cleanup:
        clean_duplicate_markers()

    mappings = {}
    for ch in range(channel_count()):
        name = channel_name(ch)
        found = markers_in_name(name)
        if found:
            mappings[found[-1]] = ch

    last_mapping_scan = now()


def maybe_rebuild_mappings():
    if (now() - last_mapping_scan) >= MAPPING_SCAN_INTERVAL:
        rebuild_mappings(False)


def remove_specific_marker(ch, pad):
    name = channel_name(ch)
    pattern = re.compile(
        r"\s*(?:\[NK2:P{}\]|‹NK2:P{}›)".format(int(pad), int(pad))
    )
    new_name = pattern.sub("", name or "").strip()
    if new_name != name:
        set_channel_name(ch, new_name)


def remove_all_markers(ch):
    name = channel_name(ch)
    new_name = strip_markers(name)
    if new_name != name:
        set_channel_name(ch, new_name)


def remove_pad_everywhere(pad):
    for ch in range(channel_count()):
        remove_specific_marker(ch, pad)


def assign_toggle(pad):
    rebuild_mappings(cleanup=True)

    ch = selected_channel()
    if not is_valid_channel(ch):
        hint("Kein gültiger Channel ausgewählt.")
        return

    old_ch = mappings.get(int(pad))
    name = channel_name(ch)
    clean = strip_markers(name)

    # Gleiche Zuordnung erneut: lösen.
    if old_ch == ch:
        remove_specific_marker(ch, pad)
        hint("Gelöst: P{} von Channel {}".format(pad, ch + 1))
        rebuild_mappings(cleanup=True)
        sync_mute_cache()
        render_leds()
        return

    # Taste war mit anderem Channel verbunden.
    if old_ch is not None and is_valid_channel(old_ch):
        remove_specific_marker(old_ch, pad)

    # Pro Channel nur eine nanoKONTROL2-Zuordnung.
    remove_all_markers(ch)

    # Taste darf nur einen Channel steuern.
    remove_pad_everywhere(pad)

    new_name = (clean + " " + make_marker(pad)).strip()

    if set_channel_name(ch, new_name):
        hint("Verlinkt: P{} -> Channel {} ({})".format(pad, ch + 1, clean))
    else:
        hint("Verlinkung fehlgeschlagen.")

    rebuild_mappings(cleanup=True)
    sync_mute_cache()
    render_leds()


def send_led(pad, value):
    global led_send_error_count

    cc = PAD_CCS[int(pad) - 1]

    try:
        # nanoKONTROL2 nutzt einen globalen MIDI-Kanal.
        # 0 = MIDI-Kanal 1. Bei abweichendem Global Channel muss dieser Wert angepasst werden.
        device.midiOutMsg(midi.MIDI_CONTROLCHANGE, 0, cc, int(value))
    except Exception as exc:
        led_send_error_count += 1
        if led_send_error_count <= 3:
            hint("LED-Sendefehler: Output-Port und Global MIDI Channel prüfen. {}".format(exc))


def led_value(pad):
    ch = mappings.get(int(pad))

    if ch is None or not is_valid_channel(ch):
        return LED_OFF

    if is_muted(ch):
        return LED_ON

    return LED_ON if pulse_active else LED_OFF


def render_leds():
    """
    Zentrale LED-Engine für alle 24 Tasten.
    """
    maybe_rebuild_mappings()

    for pad in range(1, 25):
        send_led(pad, led_value(pad))


def handle_pad(pad):
    rebuild_mappings(False)

    ch = mappings.get(int(pad))

    if ch is None or not is_valid_channel(ch):
        hint("P{} frei. CYCLE drücken, dann Solo/Mute/Record-Taste drücken.".format(pad))
        render_leds()
        return

    if toggle_mute(ch):
        last_mute_states[ch] = is_muted(ch)
        hint("P{} -> Channel {} Mute {}".format(
            pad,
            ch + 1,
            "AN" if is_muted(ch) else "AUS"
        ))
        render_leds()


def send_transport_led(cc, value):
    global led_send_error_count

    try:
        device.midiOutMsg(
            midi.MIDI_CONTROLCHANGE,
            0,  # Global MIDI Channel 1
            int(cc),
            int(value)
        )
    except Exception as exc:
        led_send_error_count += 1
        if led_send_error_count <= 3:
            hint(
                "Transport-LED-Sendefehler: Output-Port und Global MIDI Channel prüfen. {}".format(
                    exc
                )
            )


def mirror_transport_led(cc, value):
    """
    Spiegelt den tatsächlich eingehenden MIDI-Wert auf die LED.
    Dadurch übernimmt das Script direkt das im KORG Editor konfigurierte Verhalten:
    - Momentary: 127 beim Drücken, 0 beim Loslassen
    - Toggle: abwechselnd 127 und 0
    """
    send_transport_led(cc, value)


def clear_transport_leds():
    for cc in TRANSPORT_TOGGLE_CCS:
        send_transport_led(cc, LED_OFF)


def get_beat_key():
    try:
        step_pos = int(mixer.getSongStepPos())
        return step_pos // STEPS_PER_BEAT
    except Exception:
        return None


def update_pulse():
    global pulse_active, pulse_until, last_beat_key, last_beat_time

    t = now()

    try:
        playing = bool(transport.isPlaying())
    except Exception:
        playing = False

    if not playing:
        if pulse_active:
            pulse_active = False
            pulse_until = 0.0
            last_beat_key = None
            render_leds()
        return

    beat_key = get_beat_key()
    if beat_key is None:
        return

    if last_beat_key is None:
        last_beat_key = beat_key
        last_beat_time = t
        pulse_active = True
        pulse_until = t + PULSE_SECONDS
        render_leds()
        return

    if beat_key != last_beat_key:
        if beat_key < last_beat_key or (t - last_beat_time) >= MIN_BEAT_INTERVAL:
            last_beat_key = beat_key
            last_beat_time = t
            pulse_active = True
            pulse_until = t + PULSE_SECONDS
            render_leds()

    if pulse_active and t >= pulse_until:
        pulse_active = False
        render_leds()


def sync_mute_cache():
    global last_mute_states

    last_mute_states = {}
    for ch in mappings.values():
        if ch is not None and is_valid_channel(ch):
            last_mute_states[ch] = is_muted(ch)


def poll_mute_changes():
    global last_mute_poll

    t = now()
    if (t - last_mute_poll) < MUTE_POLL_INTERVAL:
        return

    last_mute_poll = t
    maybe_rebuild_mappings()

    changed = False
    seen = set()

    for ch in mappings.values():
        if ch is None or not is_valid_channel(ch):
            continue

        seen.add(ch)
        muted = is_muted(ch)

        if ch not in last_mute_states:
            last_mute_states[ch] = muted
            continue

        if last_mute_states[ch] != muted:
            last_mute_states[ch] = muted
            changed = True

    for ch in list(last_mute_states.keys()):
        if ch not in seen:
            del last_mute_states[ch]
            changed = True

    if changed:
        render_leds()


def initialize_project_state():
    rebuild_mappings(cleanup=True)
    sync_mute_cache()
    render_leds()


def OnInit():
    hint("Korg nanoKONTROL2 Link Pads v1.2 geladen.")
    initialize_project_state()


def OnProjectLoad(status):
    initialize_project_state()


def OnDeInit():
    for pad in range(1, 25):
        send_led(pad, LED_OFF)
    clear_transport_leds()


def OnControlChange(event):
    global link_armed

    cc = int(event.data1)
    val = int(event.data2)

    if cc == CYCLE_CC:
        if val > 0:
            link_armed = True
            hint("Link-Modus AN. Jetzt Solo/Mute/Record-Taste drücken.")
        event.handled = True
        return

    # Übrige Transporttasten:
    # Eingehenden Wert direkt an die LED zurückspiegeln.
    # So bestimmt der KORG Editor pro Taste Momentary oder Toggle.
    # Event bleibt für "Link to controller" in FL verfügbar.
    if cc in TRANSPORT_TOGGLE_CCS:
        mirror_transport_led(cc, val)
        event.handled = False
        return

    pad = pad_from_cc(cc)
    if pad is not None:
        if val > 0:
            if link_armed:
                link_armed = False
                assign_toggle(pad)
            else:
                handle_pad(pad)

        event.handled = True
        return

    # Fader, Knobs und übrige Transporttasten bleiben frei für FL/generische Links.
    event.handled = False


def OnMidiIn(event):
    event.handled = False


def OnIdle():
    poll_mute_changes()
    update_pulse()


def OnRefresh(flags):
    poll_mute_changes()
    update_pulse()


def OnDirtyChannel(index, flag):
    poll_mute_changes()
    render_leds()


def OnUpdateBeatIndicator(value):
    pass
